import logging
import asyncio
import sys
import io
from datetime import datetime
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    ReplyKeyboardMarkup, KeyboardButton
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, ContextTypes, filters
)
from database import Database
from config import BOT_TOKEN, ADMIN_IDS, BOT_NAME, BOT_USERNAME, PAYMENT_METHODS, SUPPORT_USERNAME

# Windows কনসোলে বাংলা ও ইউনিকোড সঠিক প্রদর্শনের জন্য এনকোডিং ফিক্স
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

db = Database()


def is_admin(user_id: int) -> bool:
    admin_list = [int(x) for x in ADMIN_IDS if str(x).isdigit()]
    if user_id in admin_list:
        return True
    if not admin_list:
        ADMIN_IDS.append(user_id)
        return True
    return False


def main_menu_keyboard():
    # ইউজার ইন্টারফেসের জন্য পরিচ্ছন্ন ও আকর্ষণীয় মেনু লেআউট
    keyboard = [
        [KeyboardButton("📚 SSC"), KeyboardButton("📚 HSC 28")],
        [KeyboardButton("📚 HSC 27"), KeyboardButton("📚 HSC 26")],
        [KeyboardButton("🎓 আমার কোর্সসমূহ"), KeyboardButton("👤 Profile")],
        [KeyboardButton("🔍 কোর্স সার্চ"), KeyboardButton("ℹ️ Info")],
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


WELCOME_MESSAGE = f"""আসসালামু আলাইকুম! 👋

🎓 **{BOT_NAME}**-এ আপনাকে স্বাগতম!

এখানে আপনি আপনার প্রয়োজনীয় যেকোনো একাডেমিক ও ভর্তি প্রস্তুতির কোর্স খুব সহজেই খুঁজে পাবেন, ক্রয় করতে পারবেন এবং তাৎক্ষণিকভাবে কোর্সের প্রিমিয়াম অ্যাক্সেস পেয়ে যাবেন।

✨ **আমাদের বিশেষ সুবিধাসমূহ:**
• 🎥 ফুল এইচডি রেকর্ডেড ক্লাস ও নিয়মিত লাইভ সেশন
• 📝 সেরা মানের লেকচার শিট, হ্যান্ডনোট ও প্রশ্নব্যাংক
• ⚡ বিকাশ, নগদ ও রকেটের মাধ্যমে ইনস্ট্যান্ট পেমেন্ট
• 🔒 ২৪/৭ নির্ভরযোগ্য ডেলিভারি ও এডমিন সাপোর্ট

👇 **শুরু করতে নিচের কীবোর্ড থেকে আপনার ব্যাচ/অপশন নির্বাচন করুন:**"""


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.add_user(user.id, user.username or "", user.full_name)

    if not ADMIN_IDS and user.id not in ADMIN_IDS:
        ADMIN_IDS.append(user.id)
        logger.info(f"প্রাথমিক অ্যাডমিন যুক্ত করা হয়েছে: {user.id} (@{user.username})")
    elif user.id not in ADMIN_IDS and len(ADMIN_IDS) == 0:
        ADMIN_IDS.append(user.id)

    logger.info(f"ইউজার স্টার্ট করেছে: {user.id} | @{user.username} | {user.full_name}")

    if context.args:
        arg = context.args[0]
        if arg.startswith("course_"):
            course_id = arg.replace("course_", "")
            course = db.get_course(course_id)
            if course:
                await send_course_details(update.message, context, course, user.id)
                return

    await update.message.reply_text(
        WELCOME_MESSAGE, parse_mode="Markdown", reply_markup=main_menu_keyboard()
    )


async def show_categories(update: Update, context: ContextTypes.DEFAULT_TYPE):
    categories = db.get_categories()
    if not categories:
        categories = ["SSC", "HSC 28", "HSC 27", "HSC 26"]

    keyboard = []
    row = []
    for cat in categories:
        row.append(InlineKeyboardButton(f"📚 {cat}", callback_data=f"cat_{cat}"))
        if len(row) == 2:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)

    text = "📋 **আপনার Batch/Class নির্বাচন করুন:**\n━━━━━━━━━━━━━━━━━━━━"
    
    if update.callback_query:
        if update.callback_query.message.photo:
            try:
                await update.callback_query.message.delete()
            except Exception:
                pass
            await update.callback_query.message.reply_text(
                text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard)
            )
        else:
            await update.callback_query.edit_message_text(
                text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard)
            )
    else:
        await update.message.reply_text(
            text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard)
        )


def get_programs_keyboard(category: str):
    keyboard = [
        [InlineKeyboardButton("🎓 একাডেমিক প্রোগ্রাম", callback_data=f"prog_academy_{category}")],
        [InlineKeyboardButton("📝 রিভিশন / স্পেশাল প্রোগ্রাম", callback_data=f"prog_revision_{category}")],
    ]
    # SSC এর জন্য এডমিশন প্রোগ্রাম বাটন বাদ দেওয়া হয়েছে
    if category.strip().upper() != "SSC":
        keyboard.append([InlineKeyboardButton("🎯 এডমিশন / প্রি-এডমিশন প্রোগ্রাম", callback_data=f"prog_admission_{category}")])
    
    keyboard.append([InlineKeyboardButton("🔙 BACK", callback_data="back_to_categories")])
    return InlineKeyboardMarkup(keyboard)


async def show_programs(query, category: str):
    text = f"📖 **{category} এর জন্য প্রোগ্রাম নির্বাচন করুন:**\n━━━━━━━━━━━━━━━━━━━━\nআপনার পছন্দের প্রোগ্রামটি সিলেক্ট করুন:"
    if query.message.photo:
        try:
            await query.message.delete()
        except Exception:
            pass
        await query.message.reply_text(
            text,
            parse_mode="Markdown",
            reply_markup=get_programs_keyboard(category)
        )
    else:
        await query.edit_message_text(
            text,
            parse_mode="Markdown",
            reply_markup=get_programs_keyboard(category)
        )


async def send_course_details(target, context: ContextTypes.DEFAULT_TYPE, course: dict, user_id: int, is_edit=False):
    course_id = course["id"]
    is_purchased = db.is_purchased(user_id, course_id)
    price = course.get("price", 0)
    discount = context.user_data.get("discounted_price") if context.user_data.get("coupon_course") == course_id else None
    
    if discount is not None:
        display_price = f"~{price} ৳~ ➡️ {discount} ৳ (কুপন ডিসকাউন্ট প্রয়োগ করা হয়েছে!)"
    else:
        display_price = f"৳{price}" if price > 0 else "বিনামূল্যে (Free) 🎁"

    # প্রফেশনাল ও আধুনিক ব্যানার কার্ড ফরম্যাট (ইউজারের স্ক্রিনশটের স্টাইল)
    msg = f"""▌ {course['name']} ❝
💰 Price: {display_price} ❝

📋 🚀 {course['name']} ❝
━━━━━━━━━━━━━━━━━━━━━━━━
📚 {course.get('description', 'কোর্সের বিস্তারিত তথ্য শিগগিরই যুক্ত করা হবে।')}

👨‍🏫 Teacher Panel / Instructor:
{course.get('instructor', 'অভিজ্ঞ শিক্ষকবৃন্দ')}

✨ কোর্সে যা যা থাকছে:
{course.get('features', '🔹 Topic-wise HD Revision Class\n🔹 প্রতিটি ক্লাসের Lecture Sheet')}"""

    keyboard = []
    if is_purchased:
        msg += "\n\n🎉 আপনি ইতিমধ্যে এই কোর্সে এনরোল করেছেন!"
        access_link = course.get("access_link", "")
        if access_link:
            keyboard.append([InlineKeyboardButton("🔗 সরাসরি কোর্স লিংকে যান", url=access_link)])
        keyboard.append([InlineKeyboardButton("🔙 ব্যাকে যান", callback_data=f"prog_{course.get('program', 'academy')}_{course.get('category', 'HSC 28')}")])
    else:
        if price == 0:
            keyboard.append([InlineKeyboardButton("🎁 বিনামূল্যে এনরোল করুন", callback_data=f"free_enroll_{course_id}")])
        else:
            keyboard.append([
                InlineKeyboardButton("🎟️ কুপন কোড", callback_data=f"coupon_{course_id}"),
                InlineKeyboardButton("💳 এখনই কিনুন (Buy Now)", callback_data=f"buy_{course_id}")
            ])
        keyboard.append([
            InlineKeyboardButton("📤 শেয়ার করুন", callback_data=f"share_{course_id}"),
            InlineKeyboardButton("🔙 ব্যাকে যান", callback_data=f"prog_{course.get('program', 'academy')}_{course.get('category', 'HSC 28')}")
        ])

    reply_markup = InlineKeyboardMarkup(keyboard)
    image = course.get("image")

    if hasattr(target, "message"):  # CallbackQuery
        if image:
            try:
                await target.message.delete()
            except Exception:
                pass
            await target.message.reply_photo(photo=image, caption=msg, reply_markup=reply_markup)
        else:
            if is_edit and not target.message.photo:
                await target.edit_message_text(msg, reply_markup=reply_markup)
            else:
                try:
                    await target.message.delete()
                except Exception:
                    pass
                await target.message.reply_text(msg, reply_markup=reply_markup)
    else:  # Message object
        if image:
            await target.reply_photo(photo=image, caption=msg, reply_markup=reply_markup)
        else:
            await target.reply_text(msg, reply_markup=reply_markup)


async def show_my_courses(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    courses = db.get_user_courses(user_id)

    if not courses:
        msg = """🎓 **আপনার এখনও কোনো কোর্স নেওয়া নেই!**

আমাদের সেরা কোর্সগুলো দেখতে নিচের ব্যাচ থেকে আপনার ক্লাস সিলেক্ট করুন এবং পছন্দের কোর্সে এনরোল করুন।"""
        if update.callback_query:
            if update.callback_query.message.photo:
                try:
                    await update.callback_query.message.delete()
                except Exception:
                    pass
                await update.callback_query.message.reply_text(msg, parse_mode="Markdown")
            else:
                await update.callback_query.edit_message_text(msg, parse_mode="Markdown")
        else:
            await update.message.reply_text(msg, parse_mode="Markdown", reply_markup=main_menu_keyboard())
        return

    msg = f"🎓 **আপনার এনরোল করা কোর্সসমূহ ({len(courses)} টি):**\n━━━━━━━━━━━━━━━━━━━━\n\n"
    keyboard = []

    for idx, c in enumerate(courses, 1):
        msg += f"{idx}. 📖 **{c['name']}**\n"
        link = c.get("access_link", "")
        if link:
            keyboard.append([InlineKeyboardButton(f"🔗 {c['name'][:22]} এর লিঙ্ক", url=link)])
        else:
            keyboard.append([InlineKeyboardButton(f"📖 {c['name'][:22]} দেখুন", callback_data=f"course_{c['id']}")])

    msg += "\n💡 সরাসরি ক্লাসে জয়েন করতে নিচের বাটনগুলোতে ক্লিক করুন।"

    if update.callback_query:
        if update.callback_query.message.photo:
            try:
                await update.callback_query.message.delete()
            except Exception:
                pass
            await update.callback_query.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await update.callback_query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        await update.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_profile(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_data = db.get_user(user.id)
    purchased_count = len(user_data.get("purchased_courses", [])) if user_data else 0
    orders = db.get_user_orders(user.id)
    total_spent = sum(o.get("amount", 0) for o in orders if o.get("status") == "approved")

    msg = f"""👤 **আপনার শিক্ষার্থী প্রোফাইল**
━━━━━━━━━━━━━━━━━━━━

👤 **নাম:** {user.full_name}
🆔 **ইউজার আইডি:** `{user.id}`
🔹 **ইউজারনেম:** @{user.username or 'N/A'}
📅 **জয়েন করার তারিখ:** {user_data.get('joined_date', 'N/A')[:10] if user_data else 'N/A'}

📚 **এনরোলকৃত কোর্স:** {purchased_count} টি
📦 **মোট অর্ডার সংখ্যা:** {len(orders)} টি
💳 **মোট খরচ:** {total_spent} ৳

📌 আপনার অর্ডারের ইতিহাস দেখতে নিচের বাটনে ক্লিক করুন।"""

    keyboard = [
        [InlineKeyboardButton("📦 আমার অর্ডার হিস্ট্রি", callback_data="my_orders_history")],
        [InlineKeyboardButton("🎓 আমার কোর্সসমূহ", callback_data="my_courses_nav")]
    ]

    await update.message.reply_text(
        msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard)
    )


# ==================== INFO & SUPPORT MENU (স্ক্রিনশটের মতো সমৃদ্ধ হেল্প মেনু) ====================

def get_info_menu_keyboard():
    keyboard = [
        [InlineKeyboardButton("💬 Contact Support", callback_data="info_contact")],
        [InlineKeyboardButton("📖 How to Buy", callback_data="info_how_to_buy")],
        [InlineKeyboardButton("🌐 About StudyMart", callback_data="info_about")],
        [InlineKeyboardButton("📜 Terms & Policy", callback_data="info_terms")],
        [InlineKeyboardButton("💳 Payment Methods", callback_data="info_payment")]
    ]
    return InlineKeyboardMarkup(keyboard)


async def show_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = f"""ℹ️ **Info Menu**

Select an option below to learn more:"""

    if update.callback_query:
        if update.callback_query.message.photo:
            try:
                await update.callback_query.message.delete()
            except Exception:
                pass
            await update.callback_query.message.reply_text(
                text, parse_mode="Markdown", reply_markup=get_info_menu_keyboard()
            )
        else:
            await update.callback_query.edit_message_text(
                text, parse_mode="Markdown", reply_markup=get_info_menu_keyboard()
            )
    else:
        await update.message.reply_text(
            text, parse_mode="Markdown", reply_markup=get_info_menu_keyboard()
        )


async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user_id = query.from_user.id

    # Info Menu Sub-items
    if data == "info_menu":
        await show_info(update, context)

    elif data == "info_contact":
        msg = f"""💬 **Contact Support / হেল্পলাইন**
━━━━━━━━━━━━━━━━━━━━

যেকোনো কোর্স সংক্রান্ত তথ্য, পেমেন্ট হেল্প বা সমস্যার জন্য আমাদের সাপোর্ট টিমের সাথে যোগাযোগ করুন:

👨‍💻 **Admin Support:** @{SUPPORT_USERNAME}
📢 **Official Channel:** @{BOT_USERNAME}
⏰ **সাপোর্ট সময়:** সকাল ৯:০০ টা - রাত ১২:০০ টা

💡 আপনার কোনো সমস্যা থাকলে এডমিনের ইনবক্সে সরাসরি মেসেজ দিন।"""
        keyboard = [
            [InlineKeyboardButton("💬 Contact Admin", url=f"https://t.me/{SUPPORT_USERNAME}")],
            [InlineKeyboardButton("📢 Official Channel", url=f"https://t.me/{BOT_USERNAME}")],
            [InlineKeyboardButton("🔙 Back to Info Menu", callback_data="info_menu")]
        ]
        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "info_how_to_buy":
        msg = f"""📖 **How to Buy / কোর্স কেনার নিয়ম**
━━━━━━━━━━━━━━━━━━━━

আমাদের প্ল্যাটফর্ম থেকে খুব সহজেই যেকোনো কোর্স কিনতে পারবেন। নিচের ধাপগুলো অনুসরণ করুন:

1️⃣ **কোর্স নির্বাচন:** 
মেনু থেকে আপনার ব্যাচ (যেমন: SSC / HSC 28) ও পছন্দের কোর্সটি সিলেক্ট করুন।

2️⃣ **অর্ডার শুরু করুন:** 
কোর্সের বিস্তারিত দেখে **'💳 এখনই কিনুন (Buy Now)'** বাটনে চাপ দিন। (কুপন থাকলে আগে কুপন প্রয়োগ করতে পারেন)

3️⃣ **পেমেন্ট মেথড নির্বাচন:** 
বিকাশ, নগদ বা রকেট এর মধ্যে আপনার সুবিধাজনক মাধ্যম বেছে নিন।

4️⃣ **টাকা পাঠান (Send Money):** 
প্রদর্শিত নাম্বারে নির্দিষ্ট পরিমাণ টাকা Send Money করুন এবং প্রাপ্ত **TrxID (Transaction ID)** টি কপি করুন।

5️⃣ **TrxID সাবমিট:** 
TrxID টি বটে সেন্ড করলেই আপনার অর্ডার সাবমিট হয়ে যাবে।

6️⃣ **তাৎক্ষণিক অ্যাক্সেস:** 
এডমিন ট্রানজেকশন যাচাই করার সাথে সাথেই আপনার ইনবক্সে ক্লাসের প্রাইভেট লিংক ও ম্যাটেরিয়াল চলে আসবে!"""
        keyboard = [
            [InlineKeyboardButton("📚 Browse Courses", callback_data="back_to_categories")],
            [InlineKeyboardButton("💬 Contact Admin", url=f"https://t.me/{SUPPORT_USERNAME}")],
            [InlineKeyboardButton("🔙 Back to Info Menu", callback_data="info_menu")]
        ]
        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "info_about":
        msg = f"""🌐 **About StudyMart**
━━━━━━━━━━━━━━━━━━━━

**{BOT_NAME}** একটি সম্পূর্ণ অটোমেটেড এবং নির্ভরযোগ্য অনলাইন শিক্ষা সেবা প্ল্যাটফর্ম।

🎯 **আমাদের ভিশন:**
বাংলাদেশের যেকোনো প্রান্ত থেকে শিক্ষার্থীরা যাতে দেশের সেরা মেন্টরদের প্রিমিয়াম কোর্স, পূর্ণাঙ্গ লেকচার শিট ও পরীক্ষার প্রস্তুতি স্বল্প খরচে সহজেই গ্রহণ করতে পারে।

✨ **আমাদের ফিচারসমূহ:**
• 📺 লাইফটাইম অ্যাক্সেস সহ ফুল এইচডি ক্লাস
• 📑 প্র্যাকটিস শিট, দাগানো বই ও এক্সক্লুসিভ নোটস
• ⚡ দ্রুত পেমেন্ট ভেরিফিকেশন ও অটোমেটিক ডেলিভারি
• 🤝 ডেডিকেটেড স্টুডেন্ট সাপোর্ট"""
        keyboard = [
            [InlineKeyboardButton("📢 Join Community", url=f"https://t.me/{BOT_USERNAME}")],
            [InlineKeyboardButton("🔙 Back to Info Menu", callback_data="info_menu")]
        ]
        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "info_terms":
        msg = f"""📜 **Terms & Policy / নীতিমালা ও শর্তাবলী**
━━━━━━━━━━━━━━━━━━━━

১. **কোর্স অ্যাক্সেস:** ক্রয়কৃত কোর্সের ম্যাটেরিয়াল ও লিংকে আপনি লাইফটাইম অ্যাক্সেস পাবেন।
২. **পেমেন্ট ভেরিফিকেশন:** ভুল TrxID বা সঠিক টাকার কম পেমেন্ট করলে অর্ডার বাতিল হবে।
৩. **নন-রিফান্ডেবল:** ডিজিটাল কোর্স মেটেরিয়াল ও অ্যাক্সেস লিংক সরবরাহ করার পর তা রিফান্ডযোগ্য নয়।
৪. **কপিরাইট ও শেয়ারিং:** কোর্সের কন্টেন্ট অন্য কোথাও বিক্রয় বা বাণিজ্যিকভাবে শেয়ার করা সম্পূর্ণরূপে নিষিদ্ধ।
৫. **সাপোর্ট:** কোনো সমস্যা হলে সর্বদা আমাদের অফিসিয়াল এডমিনের সাথে যোগাযোগ করবেন।"""
        keyboard = [
            [InlineKeyboardButton("🔙 Back to Info Menu", callback_data="info_menu")]
        ]
        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "info_payment":
        msg = f"""💳 **Official Payment Methods**
━━━━━━━━━━━━━━━━━━━━

আমাদের অফিসিয়াল পার্সোনাল পেমেন্ট নাম্বারসমূহ:"""
        for m in PAYMENT_METHODS:
            msg += f"\n• 📱 **{m['name']}:** `{m['number']}` ({m.get('instruction', 'Personal')})"

        msg += "\n\n⚠️ **সতর্কতা:** টাকা পাঠানোর পর অবশ্যই এসএমএস থেকে TrxID কপি করে বটে সাবমিট করবেন।"
        keyboard = [
            [InlineKeyboardButton("🔙 Back to Info Menu", callback_data="info_menu")]
        ]
        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "back_to_categories":
        await show_categories(update, context)

    elif data.startswith("cat_"):
        category = data.replace("cat_", "")
        context.user_data["category"] = category
        await show_programs(query, category)

    elif data.startswith("prog_"):
        parts = data.split("_")
        program = parts[1]
        category = parts[2]
        context.user_data["program"] = program
        context.user_data["category"] = category

        courses = db.get_courses_by_filter(category=category, program=program)
        prog_title = "একাডেমিক" if program == "academy" else "রিভিশন" if program == "revision" else "এডমিশন"

        keyboard = []
        if not courses:
            keyboard.append([InlineKeyboardButton("🔙 পূর্ববর্তী মেনুতে ফিরুন", callback_data=f"cat_{category}")])
            msg_text = f"❌ দুঃখিত, **{category} - {prog_title} প্রোগ্রাম** এ বর্তমানে কোনো কোর্স পাওয়া যায়নি।"
        else:
            for course in courses:
                price_tag = f" ({course['price']} ৳)" if course.get('price', 0) > 0 else " (বিনামূল্যে 🎁)"
                is_bought = " [এনরোল করা ✅]" if db.is_purchased(user_id, course["id"]) else ""
                keyboard.append([
                    InlineKeyboardButton(
                        f"📖 {course['name']}{price_tag}{is_bought}",
                        callback_data=f"course_{course['id']}"
                    )
                ])
            keyboard.append([InlineKeyboardButton("🔙 পূর্ববর্তী মেনুতে ফিরুন", callback_data=f"cat_{category}")])
            msg_text = f"📚 **{category} | {prog_title} প্রোগ্রামের কোর্সসমূহ:**\n━━━━━━━━━━━━━━━━━━━━\nযে কোর্সের তথ্য দেখতে চান সেটিতে ক্লিক করুন:"

        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(
                msg_text,
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        else:
            await query.edit_message_text(
                msg_text,
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )

    elif data.startswith("course_"):
        course_id = data.replace("course_", "")
        course = db.get_course(course_id)
        if not course:
            await query.message.reply_text("❌ কোর্সটি খুঁজে পাওয়া যায়নি।")
            return
        context.user_data["current_course"] = course_id
        await send_course_details(query, context, course, user_id, is_edit=True)

    elif data.startswith("free_enroll_"):
        course_id = data.replace("free_enroll_", "")
        course = db.get_course(course_id)
        if course:
            db.add_purchase(user_id, course_id)
            access_link = course.get("access_link", "")
            keyboard = []
            if access_link:
                keyboard.append([InlineKeyboardButton("🔗 কোর্সের লিংকে প্রবেশ করুন", url=access_link)])
            keyboard.append([InlineKeyboardButton("🎓 আমার সকল কোর্স", callback_data="my_courses_nav")])

            msg = f"""🎉 **অভিনন্দন! আপনি বিনামূল্যে এনরোল করেছেন!**
━━━━━━━━━━━━━━━━━━━━

📖 **কোর্স:** {course['name']}
✨ **স্ট্যাটাস:** সফলভাবে যুক্ত হয়েছে!

নিচের বাটনে ক্লিক করে এখনই ক্লাসে যুক্ত হোন:"""

            if query.message.photo:
                try:
                    await query.message.delete()
                except Exception:
                    pass
                await query.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
            else:
                await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data.startswith("coupon_"):
        course_id = data.replace("coupon_", "")
        context.user_data["awaiting_coupon"] = True
        context.user_data["coupon_course"] = course_id
        text = "🎟️ **কুপন কোডটি লিখে মেসেজ পাঠান:**\n\nবাতিল করতে চাইলে /cancel লিখুন।"
        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(text, parse_mode="Markdown")
        else:
            await query.edit_message_text(text, parse_mode="Markdown")

    elif data.startswith("buy_"):
        course_id = data.replace("buy_", "")
        course = db.get_course(course_id)
        if not course:
            return

        total = context.user_data.get("discounted_price") if context.user_data.get("coupon_course") == course_id else course["price"]
        context.user_data["checkout_type"] = "single"
        context.user_data["checkout_course"] = course_id
        context.user_data["checkout_course_name"] = course["name"]
        context.user_data["checkout_total"] = total

        keyboard = []
        for method in PAYMENT_METHODS:
            keyboard.append([
                InlineKeyboardButton(
                    f"💳 {method['name']}: {method['number']}",
                    callback_data=f"pay_{method['name'].lower()}"
                )
            ])
        keyboard.append([InlineKeyboardButton("❌ বাতিল করুন", callback_data="cancel_buy")])

        msg = f"""💳 **কোর্স চেকআউট (Checkout)**
━━━━━━━━━━━━━━━━━━━━

📖 **কোর্স:** {course['name']}
💰 **পরিশোধযোগ্য মূল্য:** {total} ৳

👇 **যে মাধ্যমে পেমেন্ট করতে চান তা সিলেক্ট করুন:**"""

        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data.startswith("pay_"):
        method_key = data.replace("pay_", "")
        total = context.user_data.get("checkout_total", 0)
        c_name = context.user_data.get("checkout_course_name", "Course")

        method_name = method_key.title()
        method_number = ""
        method_ins = "Send Money (Personal)"
        for m in PAYMENT_METHODS:
            if m["name"].lower() == method_key:
                method_name = m["name"]
                method_number = m["number"]
                method_ins = m.get("instruction", "Send Money")
                break

        context.user_data["awaiting_trxid"] = True
        context.user_data["pay_method"] = method_name
        context.user_data["pay_amount"] = total

        instructions = f"""💳 **{method_name} পেমেন্ট নির্দেশনা:**
━━━━━━━━━━━━━━━━━━━━

📱 **{method_name} নাম্বার:** `{method_number}`
⚙️ **পদ্ধতি:** {method_ins}
💰 **টাকার পরিমাণ:** `{total}` ৳
📖 **কোর্স:** {c_name}

📝 **টাকা পাঠানোর নিয়মাবলী:**
১. আপনার {method_name} অ্যাপ অথবা ডায়াল কোড দিয়ে উপরে উল্লেখিত নাম্বারে `{total}` ৳ Send Money করুন।
২. পেমেন্ট সম্পন্ন হওয়ার পর প্রাপ্ত **Transaction ID (TrxID)** কপি করুন।
(যেমন: `BKG78JK90L`)
৩. TrxID টি কপি করে সরাসরি এই চ্যাটে লিখে মেসেজ পাঠান।

⚠️ **সতর্কতা:** ভুল TrxID দিলে অর্ডার বাতিল হতে পারে। বাতিল করতে চাইলে /cancel লিখুন।"""

        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(
                instructions,
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ বাতিল করুন", callback_data="cancel_trxid")]])
            )
        else:
            await query.edit_message_text(
                instructions,
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ বাতিল করুন", callback_data="cancel_trxid")]])
            )

    elif data.startswith("share_"):
        course_id = data.replace("share_", "")
        course = db.get_course(course_id)
        if course:
            share_text = f"🎓 {course['name']}\n💰 মূল্য: {course['price']} ৳\n\nএখনই জয়েন করতে টেলিগ্রাম বটের এই লিংকে ক্লিক করুন:\nhttps://t.me/{BOT_USERNAME}?start=course_{course_id}"
            await query.message.reply_text(share_text)

    elif data == "my_orders_history":
        orders = db.get_user_orders(user_id)
        if not orders:
            await query.edit_message_text("📦 আপনার কোনো অর্ডার রেকর্ড পাওয়া যায়নি।")
            return
        msg = "📦 **আপনার সাম্প্রতিক অর্ডারসমূহ:**\n━━━━━━━━━━━━━━━━━━━━\n\n"
        for o in orders[:8]:
            status_bn = "⏳ অপেক্ষমান (Pending)" if o['status'] == 'pending' else "✅ অনুমোদিত (Approved)" if o['status'] == 'approved' else "❌ বাতিল (Rejected)"
            msg += f"🔹 **অর্ডার আইডি:** `{o['order_id']}`\n📖 **কোর্স:** {o.get('course_name', 'N/A')}\n💰 **মূল্য:** {o['amount']} ৳ | {o.get('payment_method', '')}\n📌 **স্ট্যাটাস:** {status_bn}\n\n"
        await query.edit_message_text(msg, parse_mode="Markdown")

    elif data == "my_courses_nav":
        await show_my_courses(update, context)

    elif data == "cancel_buy":
        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text("❌ চেকআউট প্রক্রিয়া বাতিল করা হয়েছে।\n\nপ্রধান মেনু:", reply_markup=main_menu_keyboard())
        else:
            await query.edit_message_text("❌ চেকআউট প্রক্রিয়া বাতিল করা হয়েছে।")
            await query.message.reply_text("প্রধান মেনু:", reply_markup=main_menu_keyboard())

    elif data == "cancel_trxid":
        context.user_data["awaiting_trxid"] = False
        context.user_data.pop("pay_method", None)
        context.user_data.pop("pay_amount", None)
        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text("❌ পেমেন্ট প্রক্রিয়া বাতিল করা হয়েছে।\n\nপ্রধান মেনু:", reply_markup=main_menu_keyboard())
        else:
            await query.edit_message_text("❌ পেমেন্ট প্রক্রিয়া বাতিল করা হয়েছে।")
            await query.message.reply_text("প্রধান মেনু:", reply_markup=main_menu_keyboard())

    elif data.startswith(("admin_", "adm_", "approve_", "reject_", "ordinfo_", "edprop_")):
        await handle_admin_callback(update, context)


async def handle_user_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip() if update.message.text else ""
    user_id = update.effective_user.id

    if context.user_data.get("admin_add_course"):
        await handle_admin_course_creation(update, context)
        return

    if context.user_data.get("admin_edit_field"):
        await handle_admin_course_edit_input(update, context)
        return

    if not text:
        return

    # মেনু বাটন হ্যান্ডলিং (সকল ভ্যারিয়েন্ট সাপোর্ট)
    if text in ["📚 SSC", "SSC"]:
        context.user_data["category"] = "SSC"
        await show_programs_message(update, "SSC")
    elif text in ["📚 HSC 28", "HSC 28"]:
        context.user_data["category"] = "HSC 28"
        await show_programs_message(update, "HSC 28")
    elif text in ["📚 HSC 27", "HSC 27"]:
        context.user_data["category"] = "HSC 27"
        await show_programs_message(update, "HSC 27")
    elif text in ["📚 HSC 26", "HSC 26"]:
        context.user_data["category"] = "HSC 26"
        await show_programs_message(update, "HSC 26")
    elif text in ["📚 কোর্সসমূহ", "📚 All Courses"]:
        await show_categories(update, context)
    elif text in ["🎓 আমার কোর্সসমূহ", "🎓 My Courses", "🎓 আমার কোর্স"]:
        await show_my_courses(update, context)
    elif text in ["👤 Profile", "👤 প্রোফাইল", "Profile"]:
        await show_profile(update, context)
    elif text in ["🔍 কোর্স সার্চ", "🔍 Search"]:
        context.user_data["awaiting_search"] = True
        await update.message.reply_text("🔍 যে কোর্সটি খুঁজতে চান তার নাম বা বিষয়ের নাম লিখে মেসেজ পাঠান:")
    elif text in ["ℹ️ Info", "ℹ️ হেল্প ও সাপোর্ট", "Info"]:
        await show_info(update, context)
    elif context.user_data.get("awaiting_search"):
        await handle_search_input(update, context)
    elif context.user_data.get("awaiting_coupon"):
        await handle_coupon_input(update, context)
    elif context.user_data.get("awaiting_trxid"):
        await handle_trxid_input(update, context)
    elif context.user_data.get("admin_add_coupon"):
        await handle_admin_coupon_creation(update, context)
    elif context.user_data.get("admin_broadcasting"):
        await handle_admin_broadcast_message(update, context)


async def show_programs_message(update: Update, category: str):
    text = f"📖 **{category} এর জন্য প্রোগ্রাম নির্বাচন করুন:**\n━━━━━━━━━━━━━━━━━━━━\nআপনার পছন্দের প্রোগ্রামটি সিলেক্ট করুন:"
    await update.message.reply_text(
        text,
        parse_mode="Markdown",
        reply_markup=get_programs_keyboard(category)
    )


async def handle_search_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.message.text.strip()
    context.user_data["awaiting_search"] = False

    if query == "/cancel":
        await update.message.reply_text("সার্চ বাতিল করা হয়েছে।", reply_markup=main_menu_keyboard())
        return

    results = db.search_courses(query)
    if not results:
        await update.message.reply_text(
            f"❌ '{query}' সম্পর্কিত কোনো কোর্স খুঁজে পাওয়া যায়নি।\nকোর্স দেখতে সরাসরি নিচের ব্যাচ বাটন ব্যবহার করুন।",
            reply_markup=main_menu_keyboard()
        )
        return

    keyboard = []
    for course in results:
        price_tag = f" ({course['price']} ৳)" if course.get('price', 0) > 0 else " (Free 🎁)"
        keyboard.append([
            InlineKeyboardButton(f"📖 {course['name']}{price_tag}", callback_data=f"course_{course['id']}")
        ])

    await update.message.reply_text(
        f"🔍 **'{query}' এর সার্চ ফলাফল ({len(results)} টি পাওয়া গেছে):**\n━━━━━━━━━━━━━━━━━━━━\nকোর্সের বিস্তারিত দেখতে নিচের বাটনে চাপ দিন:",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def handle_coupon_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    context.user_data["awaiting_coupon"] = False

    if text == "/cancel":
        await update.message.reply_text("❌ কুপন প্রয়োগ বাতিল করা হয়েছে।", reply_markup=main_menu_keyboard())
        return

    course_id = context.user_data.get("coupon_course")
    user_id = update.effective_user.id
    discount = db.validate_coupon(text, user_id)

    if discount:
        course = db.get_course(course_id)
        if course:
            new_price = max(0, course["price"] - discount)
            context.user_data["discounted_price"] = new_price
            context.user_data["applied_coupon"] = text.upper()
            await update.message.reply_text(
                f"""🎉 **কুপন সফলভাবে প্রয়োগ হয়েছে!**

🏷️ **কুপন কোড:** `{text.upper()}`
💰 **মূল মূল্য:** {course['price']} ৳
🎁 **ডিসকাউন্ট:** -{discount} ৳
✨ **ডিসকাউন্টেড মূল্য:** **{new_price} ৳**""",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("💳 এখনই কিনুন", callback_data=f"buy_{course_id}")],
                    [InlineKeyboardButton("🔙 কোর্স বিস্তারিত", callback_data=f"course_{course_id}")]
                ])
            )
            return

    await update.message.reply_text(
        "❌ **ভুল কুপন কোড অথবা কুপনটির মেয়াদ শেষ হয়েছে!**",
        reply_markup=main_menu_keyboard()
    )


async def handle_trxid_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    context.user_data["awaiting_trxid"] = False

    if text == "/cancel" or text == "❌ Cancel":
        context.user_data.pop("pay_method", None)
        context.user_data.pop("pay_amount", None)
        await update.message.reply_text("❌ পেমেন্ট বাতিল করা হয়েছে।", reply_markup=main_menu_keyboard())
        return

    trxid = text.upper()
    method = context.user_data.get("pay_method", "Manual")
    total = context.user_data.get("pay_amount", 0)
    checkout_type = context.user_data.get("checkout_type", "single")
    user_id = update.effective_user.id

    order_id = f"ORD-{user_id}-{int(datetime.now().timestamp())}"
    course_name = context.user_data.get("checkout_course_name", "Course")
    course_id = context.user_data.get("checkout_course", "")
    courses_in_order = context.user_data.get("checkout_courses", [course_id] if course_id else [])

    order_data = {
        "user_id": user_id,
        "username": update.effective_user.username or "",
        "full_name": update.effective_user.full_name or "",
        "course_id": course_id,
        "courses": courses_in_order,
        "course_name": course_name,
        "amount": total,
        "payment_method": method,
        "trxid": trxid,
        "status": "pending",
        "date": str(datetime.now())
    }

    db.add_order(order_id, order_data)

    coupon = context.user_data.pop("applied_coupon", None)
    if coupon:
        db.use_coupon(coupon, user_id)

    context.user_data.pop("discounted_price", None)
    context.user_data.pop("pay_method", None)
    context.user_data.pop("pay_amount", None)
    context.user_data.pop("checkout_course", None)
    context.user_data.pop("checkout_courses", None)

    await update.message.reply_text(
        f"""✅ **আপনার অর্ডারটি সফলভাবে জমা হয়েছে!**
━━━━━━━━━━━━━━━━━━━━

📦 **অর্ডার আইডি:** `{order_id}`
📖 **কোর্স:** {course_name}
💰 **পরিশোধিত টাকা:** {total} ৳
💳 **মাধ্যম:** {method}
🔑 **TrxID:** `{trxid}`

⏳ **এডমিন খুব শীঘ্রই আপনার TrxID যাচাই করে কোর্সটি অ্যাপ্রুভ করবেন।**
অ্যাপ্রুভ হওয়ার সাথে সাথে আপনি এখানে নোটিফিকেশন ও অ্যাক্সেস লিংক পেয়ে যাবেন।

📌 অর্ডারের স্ট্যাটাস জানতে: `/status {order_id}`""",
        parse_mode="Markdown",
        reply_markup=main_menu_keyboard()
    )

    admin_msg = f"""🔔 **নতুন পেমেন্ট ও অর্ডার এসেছে!**
━━━━━━━━━━━━━━━━━━━━

📦 **অর্ডার আইডি:** `{order_id}`
👤 **শিক্ষার্থী:** {update.effective_user.full_name} (@{update.effective_user.username or 'N/A'})
🆔 **ইউজার আইডি:** `{user_id}`
📖 **কোর্স:** {course_name}
💰 **টাকার পরিমাণ:** {total} ৳
💳 **পেমেন্ট মেথড:** {method}
🔑 **TrxID:** `{trxid}`
📅 **সময়:** {datetime.now().strftime('%Y-%m-%d %I:%M %p')}"""

    admin_keyboard = [
        [
            InlineKeyboardButton("✅ অনুমোদন করুন (Approve)", callback_data=f"approve_{order_id}"),
            InlineKeyboardButton("❌ বাতিল করুন (Reject)", callback_data=f"reject_{order_id}")
        ]
    ]

    for aid in ADMIN_IDS:
        try:
            await context.bot.send_message(
                aid, admin_msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(admin_keyboard)
            )
        except Exception as e:
            logger.error(f"অ্যাডমিন {aid} কে মেসেজ পাঠাতে ত্রুটি: {e}")


# ==================== ADMIN PANEL FUNCTIONS ====================

async def admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("⛔ আপনার কাছে অ্যাডমিন অ্যাক্সেস নেই!")
        return

    stats = db.get_stats()
    msg = f"""👑 **StudyMart অ্যাডমিন প্যানেল**
━━━━━━━━━━━━━━━━━━━━

📊 **এক নজরে পরিসংখ্যান:**
👥 **মোট শিক্ষার্থী:** {stats['total_users']} জন
📚 **মোট কোর্স:** {stats['total_courses']} টি
📦 **মোট অর্ডার:** {stats['total_orders']} টি
⏳ **অপেক্ষমান (Pending) অর্ডার:** {stats['pending_orders']} টি
💵 **মোট বিক্রয়/আয়:** {stats['total_revenue']} ৳

👇 **যেকোনো অপশন পরিচালনা করতে ক্লিক করুন:**"""

    keyboard = [
        [InlineKeyboardButton("📚 কোর্স ব্যবস্থাপনা", callback_data="adm_courses"), InlineKeyboardButton("📦 পেন্ডিং অর্ডারসমূহ", callback_data="adm_pending_orders")],
        [InlineKeyboardButton("🎟️ কুপন ব্যবস্থাপনা", callback_data="adm_coupons"), InlineKeyboardButton("📢 ব্রডকাস্ট নোটিশ", callback_data="adm_broadcast")],
        [InlineKeyboardButton("📊 বিস্তারিত পরিসংখ্যান", callback_data="adm_stats"), InlineKeyboardButton("📦 সকল অর্ডার তালিকা", callback_data="adm_all_orders")]
    ]

    await update.message.reply_text(
        msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def handle_admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    user_id = query.from_user.id

    if not is_admin(user_id):
        await query.answer("⛔ অ্যাক্সেস ডিনাইড!", show_alert=True)
        return

    if data == "adm_main":
        stats = db.get_stats()
        msg = f"""👑 **StudyMart অ্যাডমিন প্যানেল**
━━━━━━━━━━━━━━━━━━━━

📊 **পরিসংখ্যান:**
👥 শিক্ষার্থী: {stats['total_users']} | 📚 কোর্স: {stats['total_courses']}
📦 অর্ডার: {stats['total_orders']} (পেন্ডিং: {stats['pending_orders']})
💵 মোট আয়: {stats['total_revenue']} ৳"""

        keyboard = [
            [InlineKeyboardButton("📚 কোর্স ব্যবস্থাপনা", callback_data="adm_courses"), InlineKeyboardButton("📦 পেন্ডিং অর্ডারসমূহ", callback_data="adm_pending_orders")],
            [InlineKeyboardButton("🎟️ কুপন ব্যবস্থাপনা", callback_data="adm_coupons"), InlineKeyboardButton("📢 ব্রডকাস্ট নোটিশ", callback_data="adm_broadcast")],
            [InlineKeyboardButton("📊 বিস্তারিত পরিসংখ্যান", callback_data="adm_stats"), InlineKeyboardButton("📦 সকল অর্ডার তালিকা", callback_data="adm_all_orders")]
        ]
        await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "adm_courses":
        keyboard = [
            [InlineKeyboardButton("➕ নতুন কোর্স যুক্ত করুন", callback_data="adm_add_course")],
            [InlineKeyboardButton("📋 সকল কোর্সের তালিকা ও ডিলিট", callback_data="adm_list_courses")],
            [InlineKeyboardButton("🔙 অ্যাডমিন মেনু", callback_data="adm_main")]
        ]
        await query.edit_message_text("📚 **কোর্স ব্যবস্থাপনা মেনু:**", parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "adm_add_course":
        context.user_data["admin_add_course"] = True
        context.user_data["course_step"] = "name"
        context.user_data["new_course"] = {}
        await query.edit_message_text(
            "📝 **নতুন কোর্স সংযোজন (ধাপ ১/৮):**\n\nকোর্সের সম্পূর্ণ নাম লিখে মেসেজ পাঠান:\n(বাতিল করতে /cancel লিখুন)"
        )

    elif data == "adm_list_courses":
        courses = db.get_all_courses()
        if not courses:
            await query.edit_message_text("❌ কোনো কোর্স যুক্ত করা নেই।", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 ফিরে যান", callback_data="adm_courses")]]))
            return

        keyboard = []
        for cid, c in list(courses.items())[:30]:
            price_tag = f" ({c['price']}৳)" if c.get('price', 0) > 0 else " (ফ্রি 🎁)"
            keyboard.append([
                InlineKeyboardButton(f"📖 {c['name']}{price_tag}", callback_data=f"adm_edit_{cid}")
            ])
        keyboard.append([InlineKeyboardButton("🔙 কোর্স ব্যবস্থাপনা", callback_data="adm_courses")])

        msg_text = "📋 **বর্তমান সকল কোর্স তালিকা:**\n━━━━━━━━━━━━━━━━━━━━\nযেকোনো কোর্স সিলেক্ট করলে তার নিচে **এডিট ও ডিলিট** অপশন দেখতে পাবেন:"
        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(msg_text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await query.edit_message_text(msg_text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data.startswith("adm_delcourse_"):
        cid = data.replace("adm_delcourse_", "")
        c = db.get_course(cid)
        if c:
            db.delete_course(cid)
            await query.answer(f"✅ '{c['name']}' মুছে ফেলা হয়েছে!", show_alert=True)
            courses = db.get_all_courses()
            keyboard = []
            for id_k, val in list(courses.items())[:30]:
                price_tag = f" ({val['price']}৳)" if val.get('price', 0) > 0 else " (ফ্রি 🎁)"
                keyboard.append([
                    InlineKeyboardButton(f"📖 {val['name']}{price_tag}", callback_data=f"adm_edit_{id_k}")
                ])
            keyboard.append([InlineKeyboardButton("🔙 কোর্স ব্যবস্থাপনা", callback_data="adm_courses")])
            msg_text = "📋 **বর্তমান সকল কোর্স তালিকা:**\n━━━━━━━━━━━━━━━━━━━━\nযেকোনো কোর্স সিলেক্ট করলে তার নিচে **এডিট ও ডিলিট** অপশন দেখতে পাবেন:"
            if query.message.photo:
                try:
                    await query.message.delete()
                except Exception:
                    pass
                await query.message.reply_text(msg_text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
            else:
                await query.edit_message_text(msg_text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data.startswith("adm_edit_"):
        cid = data.replace("adm_edit_", "")
        await show_course_edit_dashboard(query, cid)

    elif data.startswith("adm_edmenu_"):
        cid = data.replace("adm_edmenu_", "")
        course = db.get_course(cid)
        if not course:
            await query.answer("কোর্স পাওয়া যায়নি!")
            return

        text = f"✏️ **'{course['name']}' এডিট মেনু:**\n━━━━━━━━━━━━━━━━━━━━\nযে তথ্যটি পরিবর্তন করতে চান সেটিতে চাপ দিন:"
        keyboard = [
            [InlineKeyboardButton("✏️ নাম পরিবর্তন", callback_data=f"edprop_{cid}_name"), InlineKeyboardButton("💰 মূল্য পরিবর্তন", callback_data=f"edprop_{cid}_price")],
            [InlineKeyboardButton("📂 ক্যাটাগরি", callback_data=f"edprop_{cid}_category"), InlineKeyboardButton("🎯 প্রোগ্রাম", callback_data=f"edprop_{cid}_program")],
            [InlineKeyboardButton("🖼️ ব্যানার ছবি", callback_data=f"edprop_{cid}_image"), InlineKeyboardButton("🔗 অ্যাক্সেস লিংক", callback_data=f"edprop_{cid}_access_link")],
            [InlineKeyboardButton("👨‍🏫 শিক্ষক প্যানেল", callback_data=f"edprop_{cid}_instructor"), InlineKeyboardButton("📝 বিবরণ ও ফিচার", callback_data=f"edprop_{cid}_description")],
            [InlineKeyboardButton("🔙 ব্যাকে যান", callback_data=f"adm_edit_{cid}")]
        ]
        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await query.edit_message_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data.startswith("edprop_"):
        parts = data.split("_")
        cid = parts[1]
        prop = parts[2]
        context.user_data["admin_edit_cid"] = cid
        context.user_data["admin_edit_field"] = prop

        prop_prompts = {
            "name": "📝 **কোর্সের নতুন নাম লিখে মেসেজ পাঠান:**",
            "price": "💰 **কোর্সের নতুন মূল্য লিখুন (সংখ্যায়, যেমন: 250 বা 0):**",
            "category": "📂 **নতুন ক্যাটাগরি লিখুন (যেমন: SSC / HSC 28 / HSC 27):**",
            "program": "🎯 **নতুন প্রোগ্রাম লিখুন (academy / revision / admission):**",
            "image": "🖼️ **নতুন ব্যানার ছবি আপলোড করুন অথবা Web Link পাঠান:**\n(ছবি মুছতে `remove` লিখুন)",
            "access_link": "🔗 **নতুন অ্যাক্সেস লিংক লিখুন (Telegram Private Channel / Drive Link):**",
            "instructor": "👨‍🏫 **নতুন শিক্ষক/টিমের নাম লিখুন (Teacher Panel):**",
            "description": "📝 **কোর্সের নতুন বিবরণ ও ফিচারসমূহ একসাথে লিখে মেসেজ পাঠান:**"
        }
        prompt = prop_prompts.get(prop, "নতুন মান লিখে পাঠান:")
        prompt += "\n\n(বাতিল করতে /cancel লিখুন)"

        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(prompt, parse_mode="Markdown")
        else:
            await query.edit_message_text(prompt, parse_mode="Markdown")

    elif data == "adm_pending_orders":
        pending = db.get_pending_orders()
        if not pending:
            await query.edit_message_text(
                "✅ বর্তমানে কোনো পেন্ডিং অর্ডার নেই!",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 অ্যাডমিন মেনু", callback_data="adm_main")]])
            )
            return

        keyboard = []
        for o in pending[:10]:
            keyboard.append([
                InlineKeyboardButton(
                    f"🔍 {o.get('course_name', 'N/A')[:18]} - {o['amount']}৳ ({o.get('payment_method', '')})",
                    callback_data=f"ordinfo_{o['order_id']}"
                )
            ])
        keyboard.append([InlineKeyboardButton("🔙 অ্যাডমিন মেনু", callback_data="adm_main")])

        await query.edit_message_text(
            f"⏳ **পেন্ডিং অর্ডারসমূহ ({len(pending)} টি):**\nযাচাই করতে অর্ডারে ক্লিক করুন:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif data.startswith("ordinfo_"):
        order_id = data.replace("ordinfo_", "")
        order = db.get_order(order_id)
        if not order:
            await query.answer("অর্ডার পাওয়া যায়নি!")
            return

        keyboard = [
            [
                InlineKeyboardButton("✅ অনুমোদন করুন", callback_data=f"approve_{order_id}"),
                InlineKeyboardButton("❌ বাতিল করুন", callback_data=f"reject_{order_id}")
            ],
            [InlineKeyboardButton("🔙 পেন্ডিং তালিকা", callback_data="adm_pending_orders")]
        ]

        await query.edit_message_text(
            f"""📦 **অর্ডারের বিস্তারিত তথ্য**
━━━━━━━━━━━━━━━━━━━━

🆔 **অর্ডার আইডি:** `{order_id}`
👤 **শিক্ষার্থী:** {order.get('full_name', 'N/A')} (@{order.get('username', 'N/A')})
🆔 **ইউজার আইডি:** `{order.get('user_id')}`
📖 **কোর্স:** {order.get('course_name', 'N/A')}
💰 **টাকা:** {order['amount']} ৳ ({order.get('payment_method', '')})
🔑 **TrxID:** `{order.get('trxid', 'N/A')}`
📅 **তারিখ:** {order.get('date', 'N/A')[:19]}
📌 **স্ট্যাটাস:** {order.get('status', '').upper()}""",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif data.startswith("approve_"):
        order_id = data.replace("approve_", "")
        order = db.get_order(order_id)
        if order and order.get("status") != "approved":
            db.update_order(order_id, {"status": "approved"})
            
            target_courses = order.get("courses", [])
            if not target_courses and order.get("course_id"):
                target_courses = [order["course_id"]]

            access_links = []
            for cid in target_courses:
                db.add_purchase(order["user_id"], cid)
                c_obj = db.get_course(cid)
                if c_obj and c_obj.get("access_link"):
                    access_links.append(f"🔗 **{c_obj['name']}:** {c_obj['access_link']}")

            access_text = "\n".join(access_links) if access_links else "আমাদের বটে '🎓 আমার কোর্সসমূহ' মেনুতে আপনার কোর্স লিংক যুক্ত করা হয়েছে।"
            user_notify = f"""🎉 **আলহামদুলিল্লাহ! আপনার পেমেন্ট অনুমোদিত হয়েছে!**
━━━━━━━━━━━━━━━━━━━━

📦 **অর্ডার আইডি:** `{order_id}`
📖 **কোর্স:** {order.get('course_name', 'N/A')}
💰 **টাকা:** {order['amount']} ৳

🎁 **আপনার কোর্সের লিংক ও অ্যাক্সেস:**
{access_text}

✨ যেকোনো সময় এই লিংক দেখতে বটে '🎓 আমার কোর্সসমূহ' বাটনে ক্লিক করুন। শুভকামনা!"""

            try:
                await context.bot.send_message(order["user_id"], user_notify, parse_mode="Markdown")
            except Exception as e:
                logger.error(f"ইউজারকে নোটিফিকেশন পাঠাতে সমস্যা: {e}")

            await query.edit_message_text(
                f"✅ **অর্ডার `{order_id}` সফলভাবে অনুমোদিত হয়েছে এবং শিক্ষার্থীকে অ্যাক্সেস লিঙ্ক পাঠানো হয়েছে!**",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 পেন্ডিং অর্ডারসমূহ", callback_data="adm_pending_orders")]])
            )

    elif data.startswith("reject_"):
        order_id = data.replace("reject_", "")
        order = db.get_order(order_id)
        if order and order.get("status") != "rejected":
            db.update_order(order_id, {"status": "rejected"})
            try:
                await context.bot.send_message(
                    order["user_id"],
                    f"""❌ **দুঃখিত! আপনার অর্ডারটি বাতিল করা হয়েছে।**
━━━━━━━━━━━━━━━━━━━━

📦 **অর্ডার আইডি:** `{order_id}`
📖 **কোর্স:** {order.get('course_name', 'N/A')}
🔑 **TrxID:** `{order.get('trxid', 'N/A')}`

⚠️ **সম্ভাব্য কারণ:** ভুল TrxID বা অপ্রতুল পেমেন্ট।
সহায়তার জন্য সরাসরি এডমিনের সাথে যোগাযোগ করুন: @{SUPPORT_USERNAME}""",
                    parse_mode="Markdown"
                )
            except Exception as e:
                logger.error(f"ইউজারকে রিজেক্ট মেসেজ পাঠাতে সমস্যা: {e}")

            await query.edit_message_text(
                f"❌ **অর্ডার `{order_id}` বাতিল করা হয়েছে!**",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 পেন্ডিং অর্ডারসমূহ", callback_data="adm_pending_orders")]])
            )

    elif data == "adm_coupons":
        coupons = db.get_all_coupons()
        keyboard = [
            [InlineKeyboardButton("➕ নতুন কুপন তৈরি করুন", callback_data="adm_add_coupon")],
            [InlineKeyboardButton("📋 সকল কুপন তালিকা ও ডিলিট", callback_data="adm_list_coupons")],
            [InlineKeyboardButton("🔙 ফিরে যান", callback_data="adm_main")]
        ]
        await query.edit_message_text(
            f"🎟️ **কুপন ব্যবস্থাপনা মেনু:**\nবর্তমানে সক্রিয় কুপন: {len(coupons)} টি",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif data == "adm_add_coupon":
        context.user_data["admin_add_coupon"] = True
        context.user_data["coupon_step"] = "code"
        await query.edit_message_text("🎟️ **কুপন কোডটি লিখুন (যেমন: SPECIAL50):**\n(বাতিল করতে /cancel)")

    elif data == "adm_list_coupons":
        coupons = db.get_all_coupons()
        if not coupons:
            await query.edit_message_text("❌ কোনো কুপন পাওয়া যায়নি।", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 ফিরে যান", callback_data="adm_coupons")]]))
            return

        keyboard = []
        for code, c in coupons.items():
            keyboard.append([
                InlineKeyboardButton(f"🗑️ ডিলিট: {code} ({c['discount']}৳ ছাড়, বাকি: {c['uses']})", callback_data=f"adm_delcoupon_{code}")
            ])
        keyboard.append([InlineKeyboardButton("🔙 ফিরে যান", callback_data="adm_coupons")])

        await query.edit_message_text("🎟️ **সক্রিয় কুপন কোডসমূহ (ডিলিট করতে ট্যাপ করুন):**", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data.startswith("adm_delcoupon_"):
        code = data.replace("adm_delcoupon_", "")
        db.delete_coupon(code)
        await query.answer(f"✅ কুপন '{code}' মুছে ফেলা হয়েছে!", show_alert=True)
        coupons = db.get_all_coupons()
        keyboard = []
        for c_code, c_val in coupons.items():
            keyboard.append([
                InlineKeyboardButton(f"🗑️ ডিলিট: {c_code} ({c_val['discount']}৳)", callback_data=f"adm_delcoupon_{c_code}")
            ])
        keyboard.append([InlineKeyboardButton("🔙 ফিরে যান", callback_data="adm_coupons")])
        await query.edit_message_text("🎟️ **সক্রিয় কুপন তালিকা:**", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "adm_broadcast":
        context.user_data["admin_broadcasting"] = True
        await query.edit_message_text(
            """📢 **ব্রডকাস্ট নোটিশ প্রেরক:**
━━━━━━━━━━━━━━━━━━━━

আপনি সকল ছাত্র-ছাত্রীদের যে বার্তা বা অফারটি পাঠাতে চান, তা সরাসরি লিখে মেসেজ পাঠান।

⚠️ মেসেজ পাঠানোর সাথে সাথে সকল বটের ব্যবহারকারী এই মেসেজটি পেয়ে যাবে।
বাতিল করতে চাইলে /cancel লিখুন।"""
        )

    elif data == "adm_stats":
        stats = db.get_stats()
        await query.edit_message_text(
            f"""📊 **বিস্তারিত ব্যবসায়িক পরিসংখ্যান**
━━━━━━━━━━━━━━━━━━━━

👥 **মোট সক্রিয় শিক্ষার্থী:** {stats['total_users']} জন
📚 **মোট প্রস্তুতকৃত কোর্স:** {stats['total_courses']} টি
📦 **মোট অর্ডার রিকোয়েস্ট:** {stats['total_orders']} টি
⏳ **পেন্ডিং অনুমোদন বাকি:** {stats['pending_orders']} টি
💵 **সর্বমোট রাজস্ব/বিক্রি:** {stats['total_revenue']} ৳""",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 ফিরে যান", callback_data="adm_main")]])
        )

    elif data == "adm_all_orders":
        orders = []
        for oid, ord_data in db.orders.items():
            ord_data["order_id"] = oid
            orders.append(ord_data)
        orders.sort(key=lambda x: x.get("date", ""), reverse=True)

        if not orders:
            await query.edit_message_text("❌ কোনো অর্ডারের রেকর্ড নেই।", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 ফিরে যান", callback_data="adm_main")]]))
            return

        keyboard = []
        for o in orders[:15]:
            status_symbol = "⏳" if o['status'] == 'pending' else "✅" if o['status'] == 'approved' else "❌"
            keyboard.append([
                InlineKeyboardButton(
                    f"{status_symbol} {o.get('course_name', 'N/A')[:16]} - {o['amount']}৳",
                    callback_data=f"ordinfo_{o['order_id']}"
                )
            ])
        keyboard.append([InlineKeyboardButton("🔙 ফিরে যান", callback_data="adm_main")])

        await query.edit_message_text(f"📦 **সাম্প্রতিক অর্ডার তালিকা (সর্বমোট {len(orders)} টি):**", reply_markup=InlineKeyboardMarkup(keyboard))


# ==================== ADMIN COURSE CREATION FLOW ====================

async def show_course_edit_dashboard(query, course_id: str, notice: str = ""):
    course = db.get_course(course_id)
    if not course:
        await query.answer("❌ কোর্সটি পাওয়া যায়নি!", show_alert=True)
        return

    price_str = f"{course['price']} ৳" if course.get('price', 0) > 0 else "বিনামূল্যে (Free) 🎁"
    has_img = "আছে ✅" if course.get("image") else "নেই ❌"
    
    msg = f"""{notice}📖 **কোর্স বিবরণ ও ম্যানেজমেন্ট**
━━━━━━━━━━━━━━━━━━━━

📖 **নাম:** {course['name']}
💰 **মূল্য:** {price_str}
📂 **ক্যাটাগরি:** {course.get('category', 'N/A')}
🎯 **প্রোগ্রাম:** {course.get('program', 'N/A').title()}
👨‍🏫 **ইন্সট্রাক্টর:** {course.get('instructor', 'N/A')}
🔗 **অ্যাক্সেস লিংক:** {course.get('access_link', 'N/A')}
🖼️ **ব্যানার ছবি:** {has_img}

📝 **বিবরণ:**
{course.get('description', 'N/A')}

✨ **ফিচারসমূহ:**
{course.get('features', 'N/A')}

👇 **এই কোর্সটি এডিট বা ডিলিট করতে নিচের অপশন বেছে নিন:**"""

    keyboard = [
        [
            InlineKeyboardButton("✏️ এডিট করুন (Edit)", callback_data=f"adm_edmenu_{course_id}"),
            InlineKeyboardButton("🗑️ ডিলিট করুন (Delete)", callback_data=f"adm_delcourse_{course_id}")
        ],
        [InlineKeyboardButton("🔙 সকল কোর্স তালিকা", callback_data="adm_list_courses")]
    ]

    image = course.get("image")
    if image:
        try:
            await query.message.delete()
        except Exception:
            pass
        await query.message.reply_photo(photo=image, caption=msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        if query.message.photo:
            try:
                await query.message.delete()
            except Exception:
                pass
            await query.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))


async def handle_admin_course_creation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip() if update.message.text else ""
    photo = update.message.photo
    step = context.user_data.get("course_step")
    new_course = context.user_data.get("new_course", {})

    if text == "/cancel":
        context.user_data["admin_add_course"] = False
        context.user_data.pop("new_course", None)
        await update.message.reply_text("❌ কোর্স সংযোজন বাতিল করা হয়েছে।", reply_markup=main_menu_keyboard())
        return

    if step == "name":
        if not text:
            await update.message.reply_text("⚠️ অনুগ্রহ করে কোর্সের নাম টেক্সট হিসেবে লিখে পাঠান:")
            return
        new_course["name"] = text
        context.user_data["new_course"] = new_course
        context.user_data["course_step"] = "price"
        await update.message.reply_text("💰 **কোর্সের মূল্য লিখুন (টাকায়, ফ্রি হলে 0 লিখুন):**")

    elif step == "price":
        try:
            new_course["price"] = int(text)
        except ValueError:
            await update.message.reply_text("⚠️ অনুগ্রহ করে সঠিক সংখ্যা লিখুন (যেমন: 200 বা 0):")
            return
        context.user_data["new_course"] = new_course
        context.user_data["course_step"] = "category"
        await update.message.reply_text("📂 **ক্যাটাগরি লিখুন (যেমন: SSC / HSC 28 / HSC 27 / HSC 26):**")

    elif step == "category":
        new_course["category"] = text.upper()
        context.user_data["new_course"] = new_course
        context.user_data["course_step"] = "program"
        await update.message.reply_text("🎯 **প্রোগ্রাম টাইপ লিখুন (academy / revision / admission):**")

    elif step == "program":
        new_course["program"] = text.lower()
        context.user_data["new_course"] = new_course
        context.user_data["course_step"] = "image"
        await update.message.reply_text(
            """🖼️ **কোর্সের ব্যানার ছবি দিন (ধাপ ৫/৮):**
━━━━━━━━━━━━━━━━━━━━

আপনি সরাসরি এখানে একটি ছবি (Photo) আপলোড করতে পারেন, অথবা ছবির Web Link/URL দিতে পারেন।

💡 ছবি না দিতে চাইলে `skip` লিখে মেসেজ পাঠান।"""
        )

    elif step == "image":
        if photo:
            new_course["image"] = photo[-1].file_id
        elif text and text.lower() != "skip":
            new_course["image"] = text
        else:
            new_course["image"] = ""

        context.user_data["new_course"] = new_course
        context.user_data["course_step"] = "instructor"
        await update.message.reply_text("👨‍🏫 **ইন্সট্রাক্টর বা টিমের নাম লিখুন (Teacher Panel):**")

    elif step == "instructor":
        new_course["instructor"] = text
        context.user_data["new_course"] = new_course
        context.user_data["course_step"] = "access_link"
        await update.message.reply_text("🔗 **কোর্সের অ্যাক্সেস লিংক লিখুন (যেমন Telegram Private Channel / Drive Link):**")

    elif step == "access_link":
        new_course["access_link"] = text
        context.user_data["new_course"] = new_course
        context.user_data["course_step"] = "description"
        await update.message.reply_text("📝 **কোর্সের সংক্ষিপ্ত বিবরণ লিখুন:**")

    elif step == "description":
        new_course["description"] = text
        context.user_data["new_course"] = new_course
        context.user_data["course_step"] = "features"
        await update.message.reply_text("✨ **কোর্সে যা যা থাকছে (কোর্সের বৈশিষ্ট্যসমূহ লিখুন):**")

    elif step == "features":
        new_course["features"] = text
        course_id = f"COURSE-{int(datetime.now().timestamp())}"
        new_course["id"] = course_id
        db.add_course(course_id, new_course)

        context.user_data["admin_add_course"] = False
        context.user_data.pop("new_course", None)

        msg = f"""🎉 **কোর্স সফলভাবে যুক্ত করা হয়েছে!**
━━━━━━━━━━━━━━━━━━━━

📖 **নাম:** {new_course['name']}
💰 **মূল্য:** {new_course['price']} ৳
📂 **ক্যাটাগরি:** {new_course['category']}
🎯 **প্রোগ্রাম:** {new_course['program']}
🔗 **অ্যাক্সেস লিংক:** {new_course['access_link']}"""

        if new_course.get("image"):
            await update.message.reply_photo(photo=new_course["image"], caption=msg, reply_markup=main_menu_keyboard())
        else:
            await update.message.reply_text(msg, reply_markup=main_menu_keyboard())


async def handle_admin_course_edit_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip() if update.message.text else ""
    photo = update.message.photo
    cid = context.user_data.get("admin_edit_cid")
    field = context.user_data.get("admin_edit_field")

    if text == "/cancel":
        context.user_data.pop("admin_edit_cid", None)
        context.user_data.pop("admin_edit_field", None)
        await update.message.reply_text("❌ এডিট প্রক্রিয়া বাতিল করা হয়েছে।", reply_markup=main_menu_keyboard())
        return

    course = db.get_course(cid)
    if not course:
        context.user_data.pop("admin_edit_cid", None)
        context.user_data.pop("admin_edit_field", None)
        await update.message.reply_text("❌ কোর্সটি খুঁজে পাওয়া যায়নি।", reply_markup=main_menu_keyboard())
        return

    updated_data = {}
    if field == "price":
        try:
            val = int(text)
            updated_data["price"] = val
        except ValueError:
            await update.message.reply_text("⚠️ অনুগ্রহ করে সঠিক সংখ্যা লিখুন (যেমন: 250 বা 0):")
            return
    elif field == "image":
        if photo:
            updated_data["image"] = photo[-1].file_id
        elif text.lower() == "remove":
            updated_data["image"] = ""
        elif text:
            updated_data["image"] = text
    elif field == "category":
        updated_data["category"] = text.upper()
    elif field == "program":
        updated_data["program"] = text.lower()
    else:
        if not text:
            await update.message.reply_text("⚠️ অনুগ্রহ করে টেক্সট লিখে পাঠান:")
            return
        updated_data[field] = text

    db.update_course(cid, updated_data)
    context.user_data.pop("admin_edit_cid", None)
    context.user_data.pop("admin_edit_field", None)

    await update.message.reply_text(
        f"✅ **'{course['name']}' এর তথ্য সফলভাবে আপডেট হয়েছে!**",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("✏️ পুনরায় এই কোর্স এডিট করুন", callback_data=f"adm_edit_{cid}")],
            [InlineKeyboardButton("📋 সকল কোর্স তালিকা", callback_data="adm_list_courses")],
            [InlineKeyboardButton("👑 অ্যাডমিন প্যানেল", callback_data="adm_main")]
        ])
    )


# ==================== ADMIN COUPON CREATION FLOW ====================

async def handle_admin_coupon_creation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    step = context.user_data.get("coupon_step")

    if text == "/cancel":
        context.user_data["admin_add_coupon"] = False
        await update.message.reply_text("❌ কুপন তৈরি বাতিল করা হয়েছে।", reply_markup=main_menu_keyboard())
        return

    if step == "code":
        context.user_data["coupon_code"] = text.upper()
        context.user_data["coupon_step"] = "discount"
        await update.message.reply_text("💰 **ডিসকাউন্টের পরিমাণ লিখুন (টাকায়, যেমন: 50):**")

    elif step == "discount":
        try:
            context.user_data["coupon_discount"] = int(text)
        except ValueError:
            await update.message.reply_text("⚠️ অনুগ্রহ করে সঠিক সংখ্যা লিখুন:")
            return
        context.user_data["coupon_step"] = "uses"
        await update.message.reply_text("🔢 **সর্বোচ্চ কতজন এই কুপন ব্যবহার করতে পারবে লিখুন (যেমন: 100):**")

    elif step == "uses":
        try:
            uses = int(text)
        except ValueError:
            await update.message.reply_text("⚠️ অনুগ্রহ করে সঠিক সংখ্যা লিখুন:")
            return

        code = context.user_data["coupon_code"]
        discount = context.user_data["coupon_discount"]
        db.add_coupon(code, discount, uses)

        context.user_data["admin_add_coupon"] = False
        context.user_data.pop("coupon_step", None)
        context.user_data.pop("coupon_code", None)
        context.user_data.pop("coupon_discount", None)

        await update.message.reply_text(
            f"""🎉 **কুপন সফলভাবে তৈরি হয়েছে!**
━━━━━━━━━━━━━━━━━━━━

🎟️ **কুপন কোড:** `{code}`
💰 **ডিসকাউন্ট:** {discount} ৳
👥 **ব্যবহারের সীমা:** {uses} বার""",
            parse_mode="Markdown",
            reply_markup=main_menu_keyboard()
        )


# ==================== ADMIN BROADCAST ====================

async def handle_admin_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    context.user_data["admin_broadcasting"] = False

    if text == "/cancel":
        await update.message.reply_text("❌ ব্রডকাস্ট বাতিল করা হয়েছে।", reply_markup=main_menu_keyboard())
        return

    user_ids = db.get_all_user_ids()
    sent_count = 0
    failed_count = 0

    progress_msg = await update.message.reply_text(f"🚀 ব্রডকাস্ট শুরু হচ্ছে... মোট ব্যবহারকারী: {len(user_ids)}")

    for uid in user_ids:
        try:
            await context.bot.send_message(
                uid,
                f"📢 **StudyMart বিশেষ বিজ্ঞপ্তি:**\n━━━━━━━━━━━━━━━━━━━━\n\n{text}",
                parse_mode="Markdown"
            )
            sent_count += 1
            await asyncio.sleep(0.05)
        except Exception:
            failed_count += 1

    await progress_msg.edit_text(
        f"""✅ **ব্রডকাস্ট সম্পন্ন হয়েছে!**
━━━━━━━━━━━━━━━━━━━━

📤 সফলভাবে পাঠানো হয়েছে: {sent_count} জন
❌ ব্যর্থ হয়েছে (ব্লক বা ডিঅ্যাক্টিভেটেড): {failed_count} জন"""
    )


# ==================== CHECK ORDER STATUS ====================

async def check_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("📌 ব্যবহার পদ্ধতি: `/status ORDER_ID`\nউদাহরণ: `/status ORD-12345-67890`", parse_mode="Markdown")
        return

    order_id = context.args[0].strip()
    order = db.get_order(order_id)

    if not order:
        await update.message.reply_text("❌ দুঃখিত, এই অর্ডারের কোনো তথ্য পাওয়া যায়নি।")
        return

    user_id = update.effective_user.id
    if order.get("user_id") != user_id and not is_admin(user_id):
        await update.message.reply_text("⛔ আপনার কাছে এই অর্ডারের তথ্য দেখার অনুমতি নেই।")
        return

    status_bn = "⏳ অপেক্ষমান (Pending)" if order['status'] == 'pending' else "✅ অনুমোদিত (Approved)" if order['status'] == 'approved' else "❌ বাতিল (Rejected)"

    msg = f"""📦 **অর্ডারের বর্তমান অবস্থা**
━━━━━━━━━━━━━━━━━━━━

🆔 **অর্ডার আইডি:** `{order_id}`
📖 **কোর্স:** {order.get('course_name', 'N/A')}
💰 **মূল্য:** {order['amount']} ৳
💳 **পেমেন্ট মেথড:** {order.get('payment_method', 'N/A')}
🔑 **TrxID:** `{order.get('trxid', 'N/A')}`
📅 **অর্ডারের সময়:** {order.get('date', 'N/A')[:19]}
📌 **বর্তমান স্ট্যাটাস:** {status_bn}"""

    if order['status'] == 'approved':
        c_obj = db.get_course(order.get('course_id', ''))
        if c_obj and c_obj.get('access_link'):
            msg += f"\n\n🔗 **কোর্স অ্যাক্সেস লিংক:** {c_obj['access_link']}"

    await update.message.reply_text(msg, parse_mode="Markdown")


# ==================== MAIN INITIALIZATION ====================

def main():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    app = Application.builder().token(BOT_TOKEN).build()

    # Commands
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin_cmd))
    app.add_handler(CommandHandler("status", check_status))
    app.add_handler(CommandHandler("courses", lambda u, c: show_categories(u, c)))
    app.add_handler(CommandHandler("mycourses", lambda u, c: show_my_courses(u, c)))
    app.add_handler(CommandHandler("profile", lambda u, c: show_profile(u, c)))
    app.add_handler(CommandHandler("help", lambda u, c: show_info(u, c)))
    app.add_handler(CommandHandler("info", lambda u, c: show_info(u, c)))

    # Callbacks
    app.add_handler(CallbackQueryHandler(handle_callback))

    # Text & Photo Messages
    app.add_handler(MessageHandler(filters.PHOTO | (filters.TEXT & ~filters.COMMAND), handle_user_input))

    print(f"==================================================")
    print(f"🚀 {BOT_NAME} কোর্স সেলিং বট সফলভাবে চালু হয়েছে!")
    print(f"🤖 ইউজারনেম: @{BOT_USERNAME}")
    print(f"📱 টেস্ট করতে টেলিগ্রামে /start পাঠান।")
    print(f"==================================================")
    
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
