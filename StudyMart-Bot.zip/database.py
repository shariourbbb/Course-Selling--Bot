import json
import os
from datetime import datetime
from typing import Dict, List, Optional
from config import COURSES_DB, USERS_DB, ORDERS_DB, COUPONS_DB, CART_DB


class Database:
    def __init__(self):
        self.courses = self._load(COURSES_DB)
        self.users = self._load(USERS_DB)
        self.orders = self._load(ORDERS_DB)
        self.coupons = self._load(COUPONS_DB)
        self.cart = self._load(CART_DB)

    def _load(self, filename: str) -> dict:
        if os.path.exists(filename):
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"Error loading {filename}: {e}")
                return {}
        return {}

    def _save(self, data: dict, filename: str):
        try:
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Error saving {filename}: {e}")

    def save_all(self):
        self._save(self.courses, COURSES_DB)
        self._save(self.users, USERS_DB)
        self._save(self.orders, ORDERS_DB)
        self._save(self.coupons, COUPONS_DB)
        self._save(self.cart, CART_DB)

    # User operations
    def add_user(self, user_id: int, username: str, full_name: str):
        uid = str(user_id)
        if uid not in self.users:
            self.users[uid] = {
                "user_id": user_id,
                "username": username or "",
                "full_name": full_name or "",
                "purchased_courses": [],
                "balance": 0,
                "joined_date": str(datetime.now())
            }
            self._save(self.users, USERS_DB)
        else:
            # Update username/full_name if changed
            updated = False
            if username and self.users[uid].get("username") != username:
                self.users[uid]["username"] = username
                updated = True
            if full_name and self.users[uid].get("full_name") != full_name:
                self.users[uid]["full_name"] = full_name
                updated = True
            if updated:
                self._save(self.users, USERS_DB)

    def get_user(self, user_id: int) -> Optional[dict]:
        return self.users.get(str(user_id))

    def get_all_user_ids(self) -> List[int]:
        return [int(uid) for uid in self.users.keys()]

    def update_user(self, user_id: int, data: dict):
        uid = str(user_id)
        if uid in self.users:
            self.users[uid].update(data)
            self._save(self.users, USERS_DB)

    def is_purchased(self, user_id: int, course_id: str) -> bool:
        user = self.get_user(user_id)
        if user:
            return course_id in user.get("purchased_courses", [])
        return False

    def add_purchase(self, user_id: int, course_id: str):
        user = self.get_user(user_id)
        if user:
            if "purchased_courses" not in user:
                user["purchased_courses"] = []
            if course_id not in user["purchased_courses"]:
                user["purchased_courses"].append(course_id)
                self._save(self.users, USERS_DB)

    def get_user_courses(self, user_id: int) -> List[dict]:
        user = self.get_user(user_id)
        if not user:
            return []
        purchased_ids = user.get("purchased_courses", [])
        result = []
        for cid in purchased_ids:
            course = self.get_course(cid)
            if course:
                c_copy = dict(course)
                c_copy["id"] = cid
                result.append(c_copy)
        return result

    # Course operations
    def add_course(self, course_id: str, data: dict):
        self.courses[course_id] = data
        self._save(self.courses, COURSES_DB)

    def get_course(self, course_id: str) -> Optional[dict]:
        course = self.courses.get(course_id)
        if course:
            c = dict(course)
            c["id"] = course_id
            return c
        return None

    def get_all_courses(self) -> dict:
        return self.courses

    def delete_course(self, course_id: str) -> bool:
        if course_id in self.courses:
            del self.courses[course_id]
            self._save(self.courses, COURSES_DB)
            return True
        return False

    def update_course(self, course_id: str, data: dict):
        if course_id in self.courses:
            self.courses[course_id].update(data)
            self._save(self.courses, COURSES_DB)

    def search_courses(self, query: str) -> List[dict]:
        query = query.strip().lower()
        results = []
        for cid, course in self.courses.items():
            name = str(course.get("name", "")).lower()
            category = str(course.get("category", "")).lower()
            instructor = str(course.get("instructor", "")).lower()
            description = str(course.get("description", "")).lower()
            if query in name or query in category or query in instructor or query in description:
                c = dict(course)
                c["id"] = cid
                results.append(c)
        return results

    # Category operations
    def get_categories(self) -> List[str]:
        categories = set()
        for course in self.courses.values():
            cat = course.get("category", "").strip()
            if cat:
                categories.add(cat)
        return sorted(list(categories))

    def get_programs(self, category: str) -> List[str]:
        programs = set()
        for course in self.courses.values():
            if course.get("category", "").strip().lower() == category.strip().lower():
                prog = course.get("program", "").strip()
                if prog:
                    programs.add(prog)
        return sorted(list(programs))

    def get_courses_by_filter(self, category: str = None, program: str = None) -> List[dict]:
        result = []
        for cid, course in self.courses.items():
            if category and course.get("category", "").strip().lower() != category.strip().lower():
                continue
            if program and course.get("program", "").strip().lower() != program.strip().lower():
                continue
            c = dict(course)
            c["id"] = cid
            result.append(c)
        return result

    # Cart operations
    def add_to_cart(self, user_id: int, course_id: str) -> bool:
        uid = str(user_id)
        if uid not in self.cart:
            self.cart[uid] = []
        if course_id not in self.cart[uid]:
            self.cart[uid].append(course_id)
            self._save(self.cart, CART_DB)
            return True
        return False

    def remove_from_cart(self, user_id: int, course_id: str) -> bool:
        uid = str(user_id)
        if uid in self.cart and course_id in self.cart[uid]:
            self.cart[uid].remove(course_id)
            self._save(self.cart, CART_DB)
            return True
        return False

    def get_cart(self, user_id: int) -> List[dict]:
        uid = str(user_id)
        course_ids = self.cart.get(uid, [])
        items = []
        for cid in course_ids:
            course = self.get_course(cid)
            if course:
                items.append(course)
        return items

    def clear_cart(self, user_id: int):
        self.cart[str(user_id)] = []
        self._save(self.cart, CART_DB)

    # Order operations
    def add_order(self, order_id: str, data: dict):
        self.orders[order_id] = data
        self._save(self.orders, ORDERS_DB)

    def get_order(self, order_id: str) -> Optional[dict]:
        order = self.orders.get(order_id)
        if order:
            o = dict(order)
            o["order_id"] = order_id
            return o
        return None

    def update_order(self, order_id: str, data: dict):
        if order_id in self.orders:
            self.orders[order_id].update(data)
            self._save(self.orders, ORDERS_DB)

    def get_user_orders(self, user_id: int) -> List[dict]:
        result = []
        for oid, order in self.orders.items():
            if order.get("user_id") == user_id:
                o = dict(order)
                o["order_id"] = oid
                result.append(o)
        result.sort(key=lambda x: x.get("date", ""), reverse=True)
        return result

    def get_pending_orders(self) -> List[dict]:
        result = []
        for oid, order in self.orders.items():
            if order.get("status") == "pending":
                o = dict(order)
                o["order_id"] = oid
                result.append(o)
        result.sort(key=lambda x: x.get("date", ""), reverse=True)
        return result

    # Coupon operations
    def add_coupon(self, code: str, discount: int, uses: int):
        self.coupons[code.upper().strip()] = {
            "discount": int(discount),
            "uses": int(uses),
            "used_by": []
        }
        self._save(self.coupons, COUPONS_DB)

    def validate_coupon(self, code: str, user_id: int) -> Optional[int]:
        clean_code = code.upper().strip()
        coupon = self.coupons.get(clean_code)
        if coupon and coupon.get("uses", 0) > 0 and user_id not in coupon.get("used_by", []):
            return coupon.get("discount", 0)
        return None

    def use_coupon(self, code: str, user_id: int):
        clean_code = code.upper().strip()
        coupon = self.coupons.get(clean_code)
        if coupon:
            coupon["uses"] = max(0, coupon.get("uses", 1) - 1)
            if "used_by" not in coupon:
                coupon["used_by"] = []
            coupon["used_by"].append(user_id)
            self._save(self.coupons, COUPONS_DB)

    def get_all_coupons(self) -> dict:
        return self.coupons

    def delete_coupon(self, code: str) -> bool:
        clean_code = code.upper().strip()
        if clean_code in self.coupons:
            del self.coupons[clean_code]
            self._save(self.coupons, COUPONS_DB)
            return True
        return False

    # Stats
    def get_stats(self) -> dict:
        total_users = len(self.users)
        total_courses = len(self.courses)
        total_orders = len(self.orders)
        pending_orders = sum(1 for o in self.orders.values() if o.get("status") == "pending")
        total_revenue = sum(
            o.get("amount", 0) for o in self.orders.values() if o.get("status") == "approved"
        )
        return {
            "total_users": total_users,
            "total_courses": total_courses,
            "total_orders": total_orders,
            "pending_orders": pending_orders,
            "total_revenue": total_revenue
        }
