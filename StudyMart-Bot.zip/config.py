BOT_TOKEN = "8977778359:AAGOn-LfnMxEGOJ8sCgNlwzIFHh_LOqjkOY"
ADMIN_IDS = [7610279126, 8167080297]  # অ্যাডমিনদের টেলিগ্রাম ইউজার আইডি (@fjgjhijhb যুক্ত করা হয়েছে)

BOT_USERNAME = "studymart0_bot"
BOT_NAME = "StudyMart"
SUPPORT_USERNAME = "StudyMartAdmin"  # আপনার টেলিগ্রাম ইউজারনেম বা সাপোর্ট ইউজারনেম

# পেমেন্ট মাধ্যম ও নাম্বারসমূহ
PAYMENT_METHODS = [
    {"name": "bKash", "number": "01XXXXXXXXX", "instruction": "Personal (Send Money)"},
    {"name": "Nagad", "number": "01XXXXXXXXX", "instruction": "Personal (Send Money)"},
    {"name": "Rocket", "number": "01XXXXXXXXX", "instruction": "Personal (Send Money)"},
]

# ডাটাবেস ফাইলসমূহ
COURSES_DB = "courses.json"
USERS_DB = "users.json"
ORDERS_DB = "orders.json"
COUPONS_DB = "coupons.json"
CART_DB = "cart.json"
